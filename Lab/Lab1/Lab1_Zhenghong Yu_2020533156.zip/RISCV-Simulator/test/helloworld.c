#include "lib.h"

int main() {
  print_s("Hello, World!\n");
  exit_proc();
}