#include "lib.h"

int main()
{

    char *a;
    a = 0x100000;
    a[0] = 'C';
    a[1] = 'C';
    a[2] = 'C';
    a[3] = 'C';
    a[4] = 'C';
    a[5] = 'C';
    a[6] = 'C';
    a[7] = 'C';
    a[8] = 'C';
    a[9] = 'C';
    exit_proc();
}