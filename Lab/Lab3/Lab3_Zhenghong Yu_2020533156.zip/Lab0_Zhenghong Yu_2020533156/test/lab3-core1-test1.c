#include "lib.h"

int main()
{

    char *a;
    a = 0x100000;
    a[10] = 'S';
    a[11] = 'S';
    a[12] = 'S';
    a[13] = 'S';
    a[14] = 'S';
    a[15] = 'S';
    a[16] = 'S';
    a[17] = 'S';
    a[18] = 'S';
    a[19] = 'S';
    exit_proc();
}